import numpy as np
import matplotlib.pyplot as plt
import math
import seaborn as sns
import tensorflow as tf
import time,os,sys
import os
import wandb
from wandb import log_artifact
from utils import make_shape
from perform import perform
from dataset import SetData, MotionDetectionDataset
from cnn import FourLayerCNN, OneChCNN
from wandb_utils import save_param_img_table, save_model, take_log

def efnb0_n(x,x1,t):#,x1,t1):
    index_1 = np.random.choice(t.shape[0], 5000, replace=False)
    x_train = x[index_1]
    t_train = t[index_1]
    index_2 = np.arange(x.shape[0])
    index_2 = np.delete(index_2, index_1)
    index_2 = np.random.choice(index_2, 1000, replace=False)
    x_test = x1[index_2]
    t_test = t[index_2]

    inputs = tf.keras.layers.Input(shape=(32, 32, 3))
    base_model = tf.keras.applications.efficientnet.EfficientNetB0(
        include_top=False,
        weights=None,
        input_tensor=inputs
    )
    x = tf.keras.layers.GlobalAveragePooling2D()(base_model.output)
    x = tf.keras.layers.BatchNormalization()(x)
    outputs = tf.keras.layers.Dense(4, activation='sigmoid')(x)
    model = tf.keras.Model(inputs, outputs)
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])#spare_categorical_crossentropy

    #初始化wandb
    wandb.init(project="EfN-B0", group="test")

    # 训练模型并记录结果
    history = model.fit(x_train, t_train, epochs=100, batch_size=20, verbose=1, validation_data=(x_test, t_test))
    acc = history.history['accuracy']
    val_acc = history.history['val_accuracy']
    loss = history.history['loss']
    val_loss = history.history['val_loss']

    # 绘制并保存训练和验证的loss和accuracy曲线
    plt.plot(range(1, len(loss) + 1), loss, 'b', label='Training loss')
    plt.plot(range(1, len(val_loss) + 1), val_loss, 'r', label='Validation loss')
    plt.title('Training and Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    wandb.log({"Training Loss": wandb.Image(plt)})

    plt.plot(range(1, len(acc) + 1), acc, 'b', label='Training accuracy')
    plt.plot(range(1, len(val_acc) + 1), val_acc, 'r', label='Validation accuracy')
    plt.title('Training and Validation Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.legend()
    wandb.log({"Training Accuracy": wandb.Image(plt)})

    plt.close()

    # history = model.fit(x_train, t_train, epochs=50, batch_size=100, verbose=1, validation_data=(x_test, t_test))
    # #loss, accuracy = model.evaluate(x_test, t_test)
    # #model.fit(x_train, t_train, epochs=100, batch_size = 800, verbose = 1, validation_data=(x_test,t_test))




    # acc = history.history['accuracy']
    # val_acc = history.history['val_accuracy']
    # loss = history.history['loss']
    # val_loss = history.history['val_loss']

    # epochs = range(1, len(acc) + 1)

    # plt.plot(epochs, loss, 'b', label='Training loss')
    # plt.plot(epochs, val_loss, 'r', label='Validation loss')
    # plt.title('Training and validation loss')
    # plt.xlabel('Epochs')
    # plt.ylabel('Loss')
    # plt.legend()
    # #fig.tight_layout()
    # plt.show()


    # plt.plot(epochs, acc, 'b', label='Training accuracy')
    # plt.plot(epochs, val_acc, 'r', label='Validation accuracy')
    # plt.title('Training and validation Accuracy')
    # plt.xlabel('Epochs')
    # plt.ylabel('Accuracy')
    # plt.legend()
    # #fig.tight_layout()
    # plt.show()



    #fig, ax1 = plt.subplots()
    #ax2 = ax1.twinx()
    #lns1 = ax1.plot([np.arange(5)], loss, label='Loss')#,
    #ax2.plot(200 * np.arange(len(accuracy)), accuracy, 'r')
    #lns2 = ax2.plot([np.arange(5)], accuracy, 'r', label='Accuracy')#
    #ax1.set_xlabel('iteration')
    #ax1.set_ylabel('training loss')
    #ax2.set_ylabel('training accuracy')
    return acc


x='orientation-detection/dataset/small_size_image/gsimage/48_over_pixel.npy'
t='orientation-detection/dataset/small_size_image/label/48_over_pixel.npy'
x1='orientation-detection/dataset/small_size_image/gsimage/48_over_pixel.npy'
#t1='orientation-detection/dataset/image/mixnoise/LABEL.npy'
x=np.load(x)/255
x1=np.load(x1)/255
t=np.load(t)
##x1=np.load(x1)
#t1=np.load(t1)

#dm=x1.shape
#print(dm)

def transuse(a):
  i,  h, w = a.shape
  x = np.zeros((3, i, h, w))
  x[0] = a
  x[1] = a
  x[2] = a
  x = np.transpose(x, (1, 2, 3, 0))
  return x

x=transuse(x)
x1=transuse(x1)
#x1,t1=transuse(x1,t1)




r = efnb0_n(x,x1,t)
print(r)