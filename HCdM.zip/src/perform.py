from tqdm import tqdm
import torch
from torch.cuda.amp import autocast, GradScaler
import torch.nn.functional as F

# def perform(model, train_loader, criterion, optimizer, scheduler, device):
#     loss_total = 0
#     accuracy_total = 0
#     count = 0
#     scaler = GradScaler(enabled=True)

#     for step, (images, labels) in tqdm(enumerate(train_loader), total=len(train_loader)):
#         # 将数据加载到设备
#         images, labels = images.to(device), labels.to(device)

#         # 确保 labels 是 1D 的 long 类型张量
#         labels = labels.view(-1).long()

#         with autocast():
#             # 前向传播
#             outputs = model(images)

#             # 计算损失
#             loss = criterion(outputs, labels)

#             # 如果需要正则化，可以启用以下代码
#             # l2_loss = 0
#             # for param in model.parameters():
#             #     l2_loss += torch.norm(param, p=2)  # L2 正则化
#             # l2_lambda = 1e-3  # L2 正则化系数
#             # loss += l2_lambda * l2_loss

#         # 计算准确率（确保使用正确的逻辑）
#         with torch.no_grad():
#             predictions = torch.argmax(outputs, dim=1)  # 获取预测的类别索引
#             accuracy = (predictions == labels).float().mean()  # 计算准确率

#         # 更新优化器
#         if optimizer is not None:
#             optimizer.zero_grad()  # 清除梯度
#             scaler.scale(loss).backward()  # 反向传播（使用 GradScaler）
#             scaler.step(optimizer)  # 更新权重
#             scaler.update()  # 更新 scaler
#             scheduler.step()  # 更新学习率调度器

#         # 累加损失和准确率
#         loss_total += loss.item() * len(images)
#         accuracy_total += accuracy.item() * len(images)
#         count += len(images)

#     # 计算平均损失和准确率
#     loss_total /= count
#     accuracy_total /= count

#     return loss_total, accuracy_total


def perform(model, train_loader, criterion, optimizer, scheduler, device):
    if len(train_loader) == 0:
        print("⚠ Warning: train_loader is empty! Skipping training...")
        return 0.0, 0.0

    loss_total = 0
    accuracy_total = 0
    count = 0
    scaler = GradScaler(enabled=True)

    for step, (images, labels) in tqdm(enumerate(train_loader), total=len(train_loader)):
        images, labels = images.to(device), labels.to(device)
        labels = labels.view(-1).long()

        with autocast():
            outputs = model(images)
            loss = criterion(outputs, labels)
            
#             # 如果需要正则化，可以启用以下代码
#             l2_loss = 0
#             for param in model.parameters():
#                 l2_loss += torch.norm(param, p=2)  # L2 正则化
#             l2_lambda = 1e-4  # L2 正则化系数
#             loss += l2_lambda * l2_loss

        with torch.no_grad():
            predictions = torch.argmax(outputs, dim=1)
            accuracy = (predictions == labels).float().mean()

        if optimizer is not None:
            optimizer.zero_grad()
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()

        if len(images) > 0:  # 确保 batch 不是空的
            loss_total += loss.item() * len(images)
            accuracy_total += accuracy.item() * len(images)
            count += len(images)

    if count > 0:
        loss_total /= count
        accuracy_total /= count
    else:
        print("⚠ Warning: No valid batches processed, setting loss and accuracy to 0.")
        loss_total = 0.0
        accuracy_total = 0.0

    return loss_total, accuracy_total

