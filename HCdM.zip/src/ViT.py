import torch
import torch.nn as nn
import torch.nn.functional as F
from timm import create_model
from timm.models.vision_transformer import VisionTransformer, PatchEmbed

# def load_vit(img_size = (32, 32)):
#     vit_model = create_model("vit_base_patch16_224", pretrained=True, num_classes=8, img_size = img_size)  # 适配8分类
    
#     return vit_model



class PatchEmbedding(nn.Module):
    def __init__(self, patch_size=16, in_channels=3, embed_dim=768):
        super().__init__()
        self.patch_size = patch_size
        self.proj = nn.Conv2d(in_channels, embed_dim, kernel_size=patch_size, stride=patch_size)
        self.cls_token = nn.Parameter(torch.randn(1, 1, embed_dim))
        self.pos_embed = nn.Parameter(torch.randn(1, 1000, embed_dim))  # 预定义足够大的位置编码
    
    def forward(self, x):
        B, C, H, W = x.shape
        num_patches = (H // self.patch_size) * (W // self.patch_size)
        x = self.proj(x).flatten(2).transpose(1, 2)  # (B, num_patches, embed_dim)

        cls_tokens = self.cls_token.expand(B, -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)  # (B, num_patches + 1, embed_dim)

        # 位置编码插值到合适大小
        pos_embed_resized = F.interpolate(self.pos_embed[:, : x.shape[1], :].permute(0, 2, 1), 
                                          size=x.shape[1], mode="linear").permute(0, 2, 1)
        x = x + pos_embed_resized

        return x

class TransformerEncoder(nn.Module):
    def __init__(self, embed_dim=768, num_heads=8, mlp_ratio=4.0, dropout=0.1):
        super().__init__()
        self.norm1 = nn.LayerNorm(embed_dim)
        self.attn = nn.MultiheadAttention(embed_dim, num_heads, dropout=dropout)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, int(embed_dim * mlp_ratio)),
            nn.GELU(),
            nn.Linear(int(embed_dim * mlp_ratio), embed_dim),
        )
        self.dropout = nn.Dropout(dropout)
    
    def forward(self, x):
        x = x + self.dropout(self.attn(self.norm1(x), self.norm1(x), self.norm1(x))[0])
        x = x + self.dropout(self.mlp(self.norm2(x)))
        return x

    

def load_vit(img_size=(32, 32), patch_size=4):
    # 创建默认的 ViT 模型
    vit_model = create_model("vit_base_patch16_224", pretrained=False, num_classes=8, img_size=img_size)

    # **修改 Patch Embedding**
    vit_model.patch_embed = PatchEmbed(
        img_size=img_size,
        patch_size=patch_size,  # 变为 3×3
        in_chans=3,
        embed_dim=vit_model.embed_dim  # 768 for ViT-Base
    )

    # **重新初始化 position embedding**
    num_patches = (img_size[0] // patch_size) * (img_size[1] // patch_size)
    vit_model.pos_embed = torch.nn.Parameter(torch.zeros(1, num_patches + 1, vit_model.embed_dim))

    return vit_model    
    
class ViT(nn.Module):
    def __init__(self, patch_size=4, in_channels=3, embed_dim=384, num_heads=6, num_layers=8, num_classes=8):
        super().__init__()
        self.patch_embed = PatchEmbedding(patch_size, in_channels, embed_dim)
        self.encoder = nn.Sequential(*[TransformerEncoder(embed_dim, num_heads) for _ in range(num_layers)])
        self.norm = nn.LayerNorm(embed_dim)
        self.head = nn.Linear(embed_dim, num_classes)
    
    def forward(self, x):
        x = self.patch_embed(x)
        x = self.encoder(x)
        x = self.norm(x[:, 0])  # 取 CLS token
        x = self.head(x)
        return x
    
    
    


# class SpatioTemporalViT(nn.Module):
#     def __init__(self, vit_model, num_patches_t=2):
#         super().__init__()
#         self.vit_model = vit_model
#         self.fc = nn.Linear(vit_model.embed_dim, 8)  # 8 分类
#         self.temporal_embedding = nn.Parameter(torch.randn(1, num_patches_t, vit_model.embed_dim))

#     def forward(self, x):
#         # x: (n, 2, 3, 32, 32) -> (n, num_patches_t * num_patches, patch_dim)
#         n, t, c, h, w = x.shape
#         x = x.view(n * t, c, h, w)  # 变成 (n*t, c, h, w)

#         # ViT 处理
#         z = self.vit_model(x)  # (n*t, embed_dim)

#         # 加入时间位置编码
#         z = z.view(n, t, -1) + self.temporal_embedding  # (n, t, embed_dim)

#         # 进一步处理（如 Transformer 融合时间信息）
#         z = z.mean(dim=1)  # 平均池化时间信息

#         return self.fc(z)
    
    
class TwoStreamViT(nn.Module):
    def __init__(self, vit_model, img_size=(32, 32)):
        super().__init__()
        self.vit_model = vit_model
        self.fc = nn.Linear(16, 8)

        # 调整 ViT 的位置编码大小
        self.resize_pos_embed(img_size)

    def resize_pos_embed(self, img_size):
        """ 根据 img_size 调整 ViT 的位置编码 """
        old_size = int((self.vit_model.pos_embed.shape[1] - 1) ** 0.5)  # 旧的 Patch Grid
        new_size = img_size[0] // self.vit_model.patch_embed.patch_size[0]  # 计算新 Patch Grid

        pos_embed = self.vit_model.pos_embed[:, 1:]  # 去掉 CLS Token
        pos_embed = pos_embed.reshape(1, old_size, old_size, -1).permute(0, 3, 1, 2)  # 变成 (1, C, H, W)
        pos_embed = F.interpolate(pos_embed, size=(new_size, new_size), mode='bilinear', align_corners=False)  # 调整大小
        pos_embed = pos_embed.permute(0, 2, 3, 1).reshape(1, new_size * new_size, -1)  # 变回 (1, N, C)

        self.vit_model.pos_embed = nn.Parameter(torch.cat([self.vit_model.pos_embed[:, :1], pos_embed], dim=1))  # 重新赋值

    def forward(self, x):
        x1, x2 = x[:, 0], x[:, 1]
        z1 = self.vit_model(x1)  # (batch_size, num_features)
        z2 = self.vit_model(x2)

    # 检查输出维度
        #print(f"z1 shape: {z1.shape}, z2 shape: {z2.shape}")

    # 处理 ViT 输出，使其匹配 fc 层
        if len(z1.shape) == 3:  # (batch_size, num_patches, embed_dim)
            z1 = z1.mean(dim=1)  # (batch_size, embed_dim)
            z2 = z2.mean(dim=1)

        z = torch.cat([z1, z2], dim=-1)  # (batch_size, 2 * embed_dim)

    # 确保 fc 层匹配输入大小
        if z.shape[1] != self.fc.in_features:
            self.fc = nn.Linear(z.shape[1], 8).to(z.device)

        output = self.fc(z)  # (batch_size, 8)
        return output

    
# class TwoStreamViT(nn.Module):
#     def __init__(self, vit_model):
#         super().__init__()
#         self.vit_model = vit_model
#         self.fc = nn.Linear(2 * vit_model.embed_dim, 8)  # 8 分类

#     def forward(self, x):
#         x1, x2 = x[:, 0], x[:, 1]  # 取出两个流

#         z1 = self.vit_model(x1)  # (batch_size, num_features)
#         z2 = self.vit_model(x2)

#         if len(z1.shape) == 3:  # 处理 patch 维度
#             z1 = z1.mean(dim=1)
#             z2 = z2.mean(dim=1)

#         z = torch.cat([z1, z2], dim=-1)  # 拼接两个流的输出 (batch_size, 2 * embed_dim)
#         return self.fc(z)  # (batch_size, 8)



class SpatioTemporalViT(nn.Module):
    def __init__(self, vit_model, num_patches_t=2):
        super().__init__()
        self.vit_model = vit_model
        self.num_patches_t = num_patches_t
        self.embed_dim = vit_model.num_features  # 适配 timm ViT

        # 创建时间嵌入
        self.temporal_embedding = nn.Parameter(torch.randn(1, num_patches_t, self.embed_dim))

        # 分类头
        self.fc = nn.Linear(self.embed_dim, 8)  # 8 分类

    def forward(self, x):
        # x: (batch_size, t, c, h, w)
        n, t, c, h, w = x.shape
        assert t == self.num_patches_t, f"时间步 ({t}) 应该与 num_patches_t ({self.num_patches_t}) 一致"

        # 变形输入适应 ViT
        x = x.view(n * t, c, h, w)  # (n*t, c, h, w)

        # 获取 ViT 特征（不含分类头）
        z = self.vit_model.forward_features(x)  # (n*t, num_patches+1, embed_dim)

        # 取 CLS Token 作为特征
        z = z[:, 0]  # (n*t, embed_dim)

        # 重新 reshape 加入时间位置编码
        z = z.view(n, t, -1) + self.temporal_embedding  # (n, t, embed_dim)

        # 时间维度平均池化
        z = z.mean(dim=1)  # (n, embed_dim)

        # 分类
        return self.fc(z)

class LSTMstViT(nn.Module):
    def __init__(self, vit_model, num_patches_t=2, hidden_dim=512, num_layers=2):
        super().__init__()
        self.vit_model = vit_model
        self.num_patches_t = num_patches_t  # 时间维度的 patch 数量
        self.embed_dim = vit_model.num_features  # ViT 输出的嵌入维度

        # LSTM 层，用于时间序列建模
        self.lstm = nn.LSTM(input_size=self.embed_dim, hidden_size=hidden_dim, num_layers=num_layers, batch_first=True)
        
        # 全连接层，用于分类
        self.fc = nn.Linear(hidden_dim, 8)  # 8 分类

    def forward(self, x):
        # x: (n, t, c, h, w)
        n, t, c, h, w = x.shape
        x = x.view(n * t, c, h, w)  # (n*t, c, h, w)

        vit_features = self.vit_model.forward_features(x)
        # ViT 处理
#         z = self.vit_model(x)  # (n*t, embed_dim)
#         z = z.view(n, t, -1)  # 重新 reshape 为 (n, t, embed_dim)

#         # 通过 LSTM 处理时间序列信息
#         z, _ = self.lstm(z)  # (n, t, hidden_dim)
        z = vit_features[:, 0, :]  # 取 LSTM 的最后一个时间步输出
        z = z.view(n, t, -1)
        z, _ = self.lstm(z)
        z = z[:, -1, :]

        # 全连接层分类
        return self.fc(z)