# 検証用コード 使いまわすことを前提に分かりやすく記載
# テスト用の画像5000枚を検証に用いる
# wandbのsweepを使って結果を保存していく

import os
import random
import pickle
from typing import Dict
import numpy as np
import omegaconf
from tqdm import tqdm
import timm

import wandb
from wandb import log_artifact

import torch
import torch.nn as nn
import torchvision
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.cuda.amp import autocast, GradScaler
import torch.nn.functional as F

import hydra
from omegaconf import DictConfig, OmegaConf

import argparse

# 自作ネットワークの定義 net.pyから呼び出し
from net import OrientationNet, Orientation2x3Net, FourLayerCNN, OneChCNN
from dataset import SetData, MotionDetectionDataset
from wandb_utils import save_param_img_table, save_model, take_log, take_detect_log, log_image_table

import copy


def perform(model, train_loader, criterion, optimizer, scheduler, device):
    loss_total = 0
    accuracy_total = 0
    count = 0
    ret_label = []
    ret_pred = []
    ret_imgs = []
    scaler = GradScaler(enabled=True)

    for step, (images, labels) in tqdm(enumerate(train_loader), total=len(train_loader)):
        onehot = torch.eye(4)[labels]
        images, onehot = images.to(device).double(), onehot.to(device).double()
        labels = labels.to(device).double()

        with autocast():
            outputs = model(images)
            outputs[torch.isnan(outputs)] = 1e-10
            #outputs = F.normalize(outputs, dim=1)
            loss = criterion(outputs, onehot).double()

        with torch.no_grad():
            accuracy = torch.mean(
                (torch.max(outputs, dim=1)[1] == labels).double())

            #log_image_table(images, torch.max(outputs, dim=1)[1], labels, outputs)
            # ret_imgs.extend(images.to('cpu').detach().numpy().copy())
            # ret_label.extend(labels.to('cpu').detach().numpy().copy())
            # ret_pred.extend(outputs)

        if optimizer is not None:
            optimizer.zero_grad()
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()

        loss_total += float(loss.detach()) * len(images)
        accuracy_total += float(accuracy.detach()) * len(images)
        count += len(images)

    loss_total = loss_total / len(train_loader)

    return loss_total / count, accuracy_total / count, ret_imgs, ret_label, ret_pred


# -----------------------------------------------------------
'''Seed setting'''


def seed_everything(seed=42):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.torch.backends.cudnn.benchmark = False
    torch.torch.backends.cudnn.enabled = True
    # 決定論的アルゴリズムを使用する
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms = True

# -----------------------------------------------------------


@hydra.main(
    version_base=None,
    config_path='../config/',
    config_name='config.yaml'
)
def main(cfg):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    seed_everything(seed=cfg.seed)
    setData = SetData(
        cfg.data.object_array,
        cfg.data.path,
        cfg.data.img_size,
        cfg.seed,
        cfg.data.is_noise,
        cfg.data.noise_num,
        cfg.split_ratio,
        cfg.dataset_num
    )

    # wandbを開始する設定
    experiment_name = f'model-num'

    run_wandb = wandb.init(
        entity=cfg.wandb.entity,  # ここはチームに応じて設定
        project=cfg.wandb.project_name,
        name=experiment_name,
        config=omegaconf.OmegaConf.to_container(
            cfg, resolve=True, throw_on_missing=True),
        notes=cfg.wandb.notes,
        save_code=cfg.wandb.is_save_code,
        # settings=wandb.Settings(start_method="thread")
    )

    cfg = wandb.config

    #学習に必要なmodel, dataloader, loss, optimizer, schedulerの定義
    valid_loader = setData.set_valid_data_Loader(
        batch_size=cfg["batch_size"],
        model=cfg["model"]["name"],
        img_size=cfg["data"]["img_size"])

    # Define Model
    model =  LeNet().to(device).double()
#     if cfg["model"]["name"] == 'Dmodel':
#         model = OrientationNet(
#             dendrite=cfg["model"]["dendrite"],
#             init_w_mul=cfg["model"]["init_w_mul"],
#             init_w_add=cfg["model"]["init_w_add"],
#             init_q=cfg["model"]["init_q"],
#             k=cfg["model"]["k"],
#             pad=cfg["model"]["pad"]
#         ).to(device).double()
#     elif cfg["model"]["name"] == 'Dmodel2x3':
#         model = Orientation2x3Net(
#             dendrite=cfg["model"]["dendrite"],
#             init_w_mul=cfg["model"]["init_w_mul"],
#             init_w_add=cfg["model"]["init_w_add"],
#             init_q=cfg["model"]["init_q"],
#             k=cfg["model"]["k"],
#             pad=cfg["model"]["pad"]
#         ).to(device).double()
#     elif cfg["model"]["name"] == 'FourLayerCNN':
#         model = FourLayerCNN().to(device).double()
#     elif cfg["model"]["name"] == 'OneChCNN':
#         model = OneChCNN().to(device).double()
#     elif cfg["model"]["name"] == 'EfficientNet':
#         model = timm.create_model(
#             model_name='tf_efficientnet_b0_ns',
#             pretrained=False,
#             num_classes=4).to(device).double()
#         # print(model)
#         print(cfg.model)
#         print(model.__sizeof__())
#    model =  LeNet().to(device).double()

    # 学習済みモデルの重みを入れる

#     artifact = run_wandb.use_artifact(
#         f'kobayu0906/OD-TrainDataRate/model:v{cfg["model"]["save_model_count"]}', type='model')
#     artifact_dir = artifact.download()

    # model load
    #print(artifact_dir)
    model.load_state_dict(torch.load(f'MDDsave/ttr7525.pth')#'C:/Users/nougata_share_pc_2/Desktop/KobayashiYuki/orientation-detection/artifacts/model-v{cfg["model"]["save_model_count"]}/model-{cfg["model"]["name"]}.pth'))
    # torch.load("C:/Users/nougata/Desktop/motion-detection/artifacts/model-v0/model-Dmodel.pth"

    #criterion = nn.CrossEntropyLoss()
    #loss
    if cfg.loss == 'CrossEntropy':
        criterion = nn.CrossEntropyLoss()
    elif cfg.loss == 'MSE':
        criterion = nn.MSELoss()
    else:
        raise Exception(
            f'指定されたLoss-{cfg.loss}-は追加されていません.このエラー文の場所に必要なModuleを追加してください.')

    # optimizer
    if cfg["optimizer"]["name"] == 'Adam':
        optimizer = optim.Adam(
            model.parameters(), lr=cfg["optimizer"]["lr"], weight_decay=cfg["optimizer"]["weight_decay"])
    else:
        raise Exception(
            f'指定されたOptimizer-{cfg["optimizer"]["name"]}-は追加されていません.このエラー文の場所に必要なModuleを追加してください.')

    # scheduler
    if cfg["scheduler"]["name"] == 'CosineAnnealingLR':
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, eta_min=cfg["scheduler"]["eta_min"], T_max=cfg["scheduler"]["T_max"])
    else:
        raise Exception(
            f'指定されたScheduler-{cfg["scheduler"]["name"]}-は追加されていません.このエラー文の場所に必要なModuleを追加してください.')

    # Dmodelでの学習の場合、初期形状の保存
#     if cfg["model"]["name"] == 'Dmodel':
#         init_model = copy.deepcopy(model)

    # 検証の実行
    wandb.watch(model, criterion, log="all", log_freq=100)

    model.eval()
    valid_loss, valid_acc, ret_imgs, ret_label, ret_pred = perform(
        model, valid_loader, criterion, None , scheduler, device)

    #print(ret_pred)
    take_detect_log(valid_acc, 0)

    # Dmodelでの学習の場合、学習後形状の保存
    # if cfg.model == 'Dmodel':
    #    save_param_img_table('learned', model)
    # save_param_img_table('init', init_model)

    # Modelの保存
    #save_model(model, cfg, run_wandb)

    wandb.finish()
    return valid_loss


if __name__ == "__main__":
    wandb.finish()
    main()
