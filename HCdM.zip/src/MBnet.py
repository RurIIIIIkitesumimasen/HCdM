from numpy import dtype
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class SiLU(nn.Module):
    def forward(self, x):
        return x * torch.sigmoid(x)


device = torch.device('cuda:0')




class OrientationNet(nn.Module):
    def __init__(
        self,
        dendrite=8,
        init_w_mul=0.01,
        init_w_add=0.2,
        init_q=0,
        pad=1,
        k=10,
    ):
        super(OrientationNet, self).__init__()
        self.frontconv = FrontConv(
            pad=pad
        )
        # self.dconvOnOff = FrontConvOnOffResponse(
        #     pad=pad
        # )
        self.dconvSynaps = DConvSynaps(
            dendrite=dendrite,
            init_w_mul=init_w_mul,
            init_w_add=init_w_add,
            init_q=init_q,
            k=k
        )
        self.dconvDend = DConvDend()
        self.dconvMenb = DConvMenb()
        #self.dbatchNorm = DBatchNorm()
        self.dconvSoma = DConvSoma()
        self.calcOutput = CalcOutput()

    # @profile
    def forward(self, x):
        x = self.frontconv(x)
        # x = self.dconvOnOff(x)
        x = self.dconvSynaps(x)
        x = self.dconvDend(x)
        x = self.dconvMenb(x)
        #x = self.dbatchNorm(x)
        x = self.dconvSoma(x)
        x = self.calcOutput(x)

        return x




class FrontConv(nn.Module):
    def __init__(
        self,
        input_dim=((2, 3, 32, 32)),#input size changing
        output_dim=((1024, 27)),#input size changing
        filter_size=3,
        pad=1
    ):
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.filter_size = filter_size
        self.pad = pad
        image_w = input_dim[2]
        self.activate = nn.Sigmoid()

    def forward(self, x):
        # im2col
        # x = torch.squeeze(x, dim=1)
        x = x.permute(0, 1, 4, 2, 3)
        x1 = x[:, 0, :, :, :]  # 取出第二维度索引为 0 的部分
        x2 = x[:, 1, :, :, :]  # 取出第二维度索引为 1 的部分

        x1 = nn.Unfold(kernel_size=(self.filter_size, self.filter_size), stride=(
            1, 1), padding=self.pad, dilation=(1, 1))(x1)
        x2 = nn.Unfold(kernel_size=(self.filter_size, self.filter_size), stride=(
            1, 1), padding=self.pad, dilation=(1, 1))(x2)


        batch, _, L = x1.shape  # 获取batch大小和L
        
        
        
        
# 分别取三个通道中心元素的值，unsqueeze(0) 让它在最前面增加一个维度
        x1_center = torch.cat([x1[:, 4, :].unsqueeze(0) for _ in range(9)], dim=0)  # 第一个通道
        x2_center = torch.cat([x1[:, 13, :].unsqueeze(0) for _ in range(9)], dim=0)  # 第二个通道
        x3_center = torch.cat([x1[:, 22, :].unsqueeze(0) for _ in range(9)], dim=0)  # 第三个通道

# 将每个中心块拼接在一起
        x_center = torch.cat([x1_center, x2_center, x3_center], dim=0)

# 重新排列维度，使得 x_center 形状为 (batch, 27, L)
        x_center = x_center.permute(1, 0, 2)  # 重新排列维度为 (batch, 27, L)

        #x_center = x_center.permute(1,0,2,3)

# 中心と周囲の比較
        x = torch.isclose(x2, x_center, rtol=0, atol=0) # |a-b| < atol + rtol×b
        # x[:, 4, ...] = ~x[:, 4, ...]
        x = x.float()
        
        # x[:, 4, :] = torch.logical_not(torch.isclose(
        # x[:, 4, :], x[:, 4, :], rtol=0, atol=self.err_center))
        # #x[:,4,:] = (x[:,4,:,0] != x[:,4,:,0]) | (x[:,4,:,1] != x[:,4,:,1]) | (x[:,4,:,2] != x[:,4,:,2])
        # #x[:,4,:] = tmp[...,0] | tmp[...,1] | tmp[...,2]
       # print(x.shape)
        #x = x.permute(0, 2, 1)
        #print(x.shape) #b, 27, L
        return x        






class DConvSynaps(nn.Module):
    def __init__(
        self,
        dendrite=8,
        init_w_mul=0.01,
        init_w_add=0.2,
        init_q=0,
        k=10
    ):
        self.dendrite = dendrite
        super().__init__()
        self.W = nn.Parameter(
            torch.Tensor(init_w_mul * np.abs(np.random.randn(self.dendrite, 27, 8)) + init_w_add)
#     torch.cat([
#         torch.Tensor(init_w_mul * np.abs(np.random.randn(self.dendrite, 9, 8)) + init_w_add),
#         torch.Tensor(-init_w_mul * np.abs(np.random.randn(self.dendrite, 9, 8)) - init_w_add)
#     ], dim=1)  # 拼接维度应为 dim=1，而非 dim=3
)

        self.q = nn.Parameter(
            torch.Tensor(init_w_mul * np.abs(np.random.randn(self.dendrite, 27, 8)) + init_q)
#     torch.cat([
#         torch.Tensor(init_w_mul * np.abs(np.random.randn(self.dendrite, 9, 8)) + init_q),
#         torch.Tensor(-init_w_mul * np.abs(np.random.randn(self.dendrite, 9, 8)) - init_q)
#     ], dim=1)  # 拼接维度应为 dim=1，而非 dim=3
) 

        self.activation = nn.Sigmoid()

        self.k = k

    def forward(self, x):
        x_width = x.shape[2]
        W = self.W.expand(x.shape[0], x_width, self.dendrite,
                          27, 8)
        q = self.q.expand(x.shape[0], x_width, self.dendrite,
                          27, 8)
        x = torch.cat([x.unsqueeze(0) for _ in range(8)], dim=0)
        x = x.unsqueeze(0) 
        # x = torch.cat([x.unsqueeze(0) for _ in range(dendrite)], dim=0)
        x = x.permute(2, 4, 0, 3, 1)
#         print(x.shape)
#         print(q.shape)
        return self.activation((x.to(device) * W - q) * self.k)


class DConvDend(nn.Module):
    def __init__(
        self
    ):
        super().__init__()

    def forward(self, x):
        return torch.prod(x, 3)


class DConvMenb(nn.Module):
    def __init__(
        self
    ):
        super().__init__()

    def forward(self, x):
        return torch.sum(x, 2)
    
# class DBatchNorm(nn.Module):
#     def __init__(self, num_features = 1024):
#         super(DBatchNorm, self).__init__()
#         self.bn = nn.BatchNorm1d(num_features = 1024)  # 批归一化层

#     def forward(self, x):
#         return self.bn(x)


class DConvSoma(nn.Module):
    def __init__(
        self
    ):
        super().__init__()
        self.activation = nn.Sigmoid()

    def forward(self, x):
        return self.activation((x - 0.5) * 10)


    
class CalcOutput(nn.Module):
    def __init__(
        self
    ):
        super().__init__()

    def forward(self, x):
        return torch.sum(x, 1)