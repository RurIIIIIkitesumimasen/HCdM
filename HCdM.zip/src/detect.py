# 検証用コード

import os
import random
import numpy as np
import omegaconf
from tqdm import tqdm
import timm

import wandb

import torch
import torch.nn as nn
import torch.optim as optim
from torch.cuda.amp import autocast, GradScaler
import torch.nn.functional as F

import hydra
from omegaconf import DictConfig, OmegaConf

# 自作ネットワークの定義
#from net.dendritic_net import DendriticNet
from testdataset import SetData
from perform import perform
from cnn import FourLayerCNN, OneChCNN, LeNet, CustomEfficientNet, EfficientNetB0
from ResNet import resnet18, resnet34, resnet50, resnet101, resnet152, resnet50_cam
from ConvNeXt import convnext_tiny
from ViT import ViT, SpatioTemporalViT, load_vit, TwoStreamViT, SpatioTemporalViT, LSTMstViT
import copy
#from utils.set_func import *
from HorizontalMBnet import OrientationNet
from perform import perform
from wandb_utils import save_param_img_table_v2, save_model, take_log, take_detect_log

def perform(model, train_loader, criterion, optimizer, scheduler, device):
    loss_total = 0
    accuracy_total = 0
    count = 0
    scaler = GradScaler(enabled=True)

    for step, (images, labels) in tqdm(enumerate(train_loader), total=len(train_loader)):
        onehot = torch.eye(8)[labels]
        images, onehot = images.to(device).double(), onehot.to(device).double()
        labels = labels.to(device).double()

        with autocast():
            outputs = model(images)
            outputs[torch.isnan(outputs)] = 1e-10
            outputs = F.normalize(outputs, dim=1)
            #loss = criterion(outputs, onehot)

        with torch.no_grad():
            accuracy = torch.mean(
                (torch.max(outputs, dim=1)[1] == labels).float())

        if optimizer is not None:
            optimizer.zero_grad()
            #scaler.scale(loss).backward()
            #scaler.step(optimizer)
            #scaler.update()
            #scheduler.step()

        loss_total += 0
        accuracy_total += float(accuracy.detach()) * len(images)
        count += len(images)

    loss_total = loss_total / len(train_loader)

    return loss_total / count, accuracy_total / count


# -----------------------------------------------------------
'''Seed setting'''


def seed_everything(seed=42):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.torch.backends.cudnn.benchmark = False
    torch.torch.backends.cudnn.enabled = True
    # 決定論的アルゴリズムを使用する
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms = True
# -----------------------------------------------------------


@hydra.main(
    version_base=None,
    config_path='../config',
    config_name='config-optuna.yaml'
)
def main(cfg):
    # GPU指定
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # SEED値固定
    seed_everything(seed=cfg.model_num_seed)

    # DataSetの設定
    setData = SetData(
        cfg.data.object_array,
        cfg.data.path,
        cfg.data.img_size,
        cfg.seed,
        cfg.data.is_noise,
        cfg.data.noise_num,
        cfg.wandb.group_name,
        cfg.wandb.experiment_name,
        cfg.modeltype
    )

    #experiment_name = f'EfN-{cfg["runtime"]}'                                         #run detect revise

    # wandbを開始する設定

    run_wandb = wandb.init(
        entity=cfg.wandb.entity,  # ここはチームに応じて設定
        project=f'{cfg["wandb"]["project_name"]}',
        group=f'{cfg["testdstype"]}',
            # name=experiment_name, #experiment_nameは必要であれば追加
        config=omegaconf.OmegaConf.to_container(
            cfg, resolve=True, throw_on_missing=True),
        save_code=cfg.wandb.is_save_code,
    )

    cfg = wandb.config

    #学習に必要なmodel, dataloader, loss, optimizer, schedulerの定義
    # 検知だけなのでvalid_loaderでok
    valid_loader = setData.set_valid_data_Loader(
        batch_size=cfg.batch_size,
        #model=cfg.model,
        #img_size=cfg.data.img_size
    )

    # Modelを作成

    if cfg["modeltype"] == 'HMBD':
        model = OrientationNet().to(device)
        
    elif cfg["modeltype"] == 'LeNet':
        model = LeNet().to(device)
        
    elif cfg["modeltype"] == '4LCNN':
        model = FourLayerCNN().to(device)
        
    elif cfg["modeltype"] == 'EfN':
        model = EfficientNetB0(num_classes = 8).to(device)
        
    elif cfg["modeltype"] == 'ResNet':
        model = resnet50_cam(num_classes = 8).to(device)
     
    elif cfg["modeltype"] == 'convnext':
        model = convnext_tiny(num_classes = 8).to(device)
    elif cfg["modeltype"] == 'LSTMstViT':
        vit_model = load_vit(img_size = (32, 32))
        model =  LSTMstViT(vit_model#, img_size = (32, 32)# num_classes = 8 #使用的模型名称
    ).to(device)
    elif cfg["modeltype"] == '2sViT':
        vit_model = load_vit(img_size = (32, 32))
        model =  TwoStreamViT(vit_model# num_classes = 8 #使用的模型名称
    ).to(device)
    else:
        model = 1
        
        
    model = model.double()

    # model load
    model.load_state_dict(torch.load(f'B:/saved_model/Weather/RGBmbTest/RGB_{cfg["modeltype"]}/{cfg["data"]["object"]}/{cfg["data"]["background"]}/{cfg["modeltype"]}-TTR{cfg["datarate"]}_{cfg["runtime"]}.pth'))   
    #model.load_state_dict(torch.load(f'B:/saved_model/Weather/Motion_RGB/{cfg["data"]["object"]}/{cfg["data"]["background"]}/{cfg["modeltype"]}/{cfg["modeltype"]}-{cfg["runtime"]}-TrainRate-{cfg["datarate"]}_epoch_final.pth'))       #run detect revise
    model.eval()
    # loss
    criterion = nn.CrossEntropyLoss()
    # optimizer
    optimizer = optim.Adam(
        model.parameters(), lr=cfg["optimizer"]["lr"], weight_decay=cfg["optimizer"]["weight_decay"])
    # scheduler
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
                              optimizer, eta_min=cfg["scheduler"]["name"], T_max=cfg["scheduler"]["T_max"])

    # Dmodelでの学習の場合、初期形状の保存
#     if cfg.model == 'Dmodel':
#         init_model = copy.deepcopy(model)
#         save_param_img_table('init', init_model)

    # 検証の実行
    wandb.watch(model, criterion, log="all", log_freq=100)

    model.eval()
    valid_loss, valid_acc = perform(
        model, valid_loader, criterion, None, scheduler, device)

    take_detect_log(valid_acc, 5)
    print(f"test acc : {valid_acc:.5f}")

    wandb.finish()
    return valid_loss
#     if cfg.model == 'Dmodel':
#         model = DendriticNet(
#             dendrite=cfg.dendrite,
#             init_mul=cfg.init_mul,
#             init_w_add=cfg.init_w_add,
#             init_q=cfg.init_q,
#             is_center_init=cfg.is_center_init,
#             init_center_shape=cfg.init_center_shape,
#             init_round_shape=cfg.init_round_shape,
#         ).to(device).double()
#     elif cfg.model == 'TwoChCNN':
#         model = TwoChCNN().to(device).double()
#     elif cfg.model == 'OneChCNN':
#         model = OneChCNN().to(device).double()
#     elif cfg.model == 'TwoChFCCNN':
#         model = TwoChFCCNN().to(device).double()
#     elif cfg.model == 'OneChFCCNN':
#         model = OneChFCCNN().to(device).double()
#     elif cfg.model == 'FourLayerCNN':
#         model = FourLayerCNN().to(device).double()
#     elif cfg.model == 'EfficientNet':
#         model = timm.create_model(
#             model_name='tf_efficientnet_b0_ns',
#             pretrained=False,
#             num_classes=8).to(device).double()
#         # print(model)
#         print(cfg.model)
#         print(model.__sizeof__())

if __name__ == "__main__":
    wandb.finish()
    main()
