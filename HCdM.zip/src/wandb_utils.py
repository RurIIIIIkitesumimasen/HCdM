import os
import random
import pickle
import numpy as np
from tqdm import tqdm

import wandb
from wandb import log_artifact

import torch
import torch.nn as nn
import torchvision
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.cuda.amp import autocast, GradScaler

from utils import make_shape


def save_param_img_table(save_time, model):

    img = make_shape(model).to('cpu').detach().numpy().copy()
    img = img.repeat(30, axis=2).repeat(30, axis=3)
    img = torch.from_numpy(img)
    img_grid = torchvision.utils.make_grid(img[:90], nrow=90)
    init_images = wandb.Image(
        img_grid, caption="0:cons=0,1:direct,2:inverse,3:cons=1")
    wandb.log({f"{save_time} synaptic shape": init_images})

    W = model.state_dict()['dconvSynaps.W'].to('cpu')
    q = model.state_dict()['dconvSynaps.q'].to('cpu')
    W_reshaped = W.permute(1, 0, 2).reshape(1, -1, W.shape[2])
    q_reshaped = q.permute(1, 0, 2).reshape(1, -1, q.shape[2]) 

    init_weight_table = wandb.Table(
        data=list(W_reshaped[0].transpose(1, 0)),
        columns=['UpLeft', 'Center', 'Up', 'Center', 'UpRight', 'Center', 'Left', 'Center',
                 'Right', 'Center', 'DownLeft', 'Center', 'Down', 'Center', 'DownRight', 'Center']
    )
    wandb.log({f'{save_time}_weight': init_weight_table})

    init_bias_table = wandb.Table(
        data=list(q_reshaped[0].transpose(1, 0)),
        columns=['UpLeft', 'Center', 'Up', 'Center', 'UpRight', 'Center', 'Left', 'Center',
                 'Right', 'Center', 'DownLeft', 'Center', 'Down', 'Center', 'DownRight', 'Center']
    )
    wandb.log({f'{save_time}_bias': init_bias_table})

    del init_weight_table, init_bias_table, W, q

    torch.cuda.empty_cache()

    
    
def save_param_img_table_v2(save_time, model):
    
    img = make_shape(model).to('cpu').detach().numpy().copy()
    img = img.repeat(30, axis=2).repeat(30, axis=3)
    img = torch.from_numpy(img)
    img_grid = torchvision.utils.make_grid(img[:90], nrow=90)
    init_images = wandb.Image(
        img_grid, caption="0:cons=0,1:direct,2:inverse,3:cons=1")
    wandb.log({f"{save_time} synaptic shape": init_images})
    
    W = model.state_dict()['dconvSynaps.W'].to('cpu')  # (80, 16, 8)
    q = model.state_dict()['dconvSynaps.q'].to('cpu')  # (80, 16, 8)

    # 定义列名和初始化表格数据
    columns = ['Branch', 'Row'] + ['UpLeft_Ex', 'Up_Ex', 'UpRight_Ex', 'Left_Ex', 'Right_Ex', 
                                   'DownLeft_Ex', 'Down_Ex', 'DownRight_Ex', 'UpLeft_Ex', 'Up_In', 
                                   'UpRight_In', 'Left_In', 'Right_In', 'DownLeft_In', 'Down_In', 'DownRight_In']
    data = []

    # 构造表格内容
    for i in range(W.shape[0]):  # 80 branches
        for j in range(W.shape[1]):  # 16 rows in each branch
            W_row = W[i, j].numpy()  # (8,)
            q_row = q[i, j].numpy()  # (8,)
            
            # 将行标题和数据拼接
            row_title = f"Branch_{i}_{j}"
            data.append([f"Branch_{i}", f"Row_{j}"] + list(W_row) + list(q_row))
    
    # 创建一个大表格
    big_table = wandb.Table(data=data, columns=columns)
    wandb.log({f"{save_time}_all_params": big_table})

    torch.cuda.empty_cache()


def save_model(model, config, run_wandb, epoch):
    # 注意修改保存的文件名
    torch.save(model.state_dict(), f'B:/saved_model/Weather/{config["modeltype"]}-TTR{config["datarate"]}_{config["runtime"]}.pth')
    artifact = wandb.Artifact(f'model_epoch_{epoch}', type='model')
    artifact.add_file(f'B:/saved_model/Weather/{config["modeltype"]}-TTR{config["datarate"]}_{config["runtime"]}.pth')
    run_wandb.log_artifact(artifact)


def take_log(train_loss, train_acc, valid_loss, valid_acc, epoch):
    wandb.log({"epoch": epoch, "train_loss": train_loss,
               "test_loss": valid_loss}, step=epoch)
    wandb.log(
        {"epoch": epoch, "train_acc": train_acc,
         "test_acc": valid_acc}, step=epoch)
    print(f"{epoch} : train --- loss: {train_loss:.5f} acc: {train_acc:.5f}, test --- loss: {valid_loss:.5f} acc: {valid_acc:.5f}")


def take_detect_log(valid_acc, epoch):
    wandb.log(
        {"epoch": epoch, "test_acc": valid_acc}, step=epoch)
    print(f"test acc : {valid_acc:.5f}")
    #print(f"{epoch} : train --- loss: {train_loss:.5f} acc: {train_acc:.5f}, test --- loss: {valid_loss:.5f} acc: {valid_acc:.5f}")
