import os
import random
import pickle
import numpy as np
from tqdm import tqdm

import wandb
from wandb import log_artifact

import torch
import torch.nn as nn
import torchvision
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.cuda.amp import autocast, GradScaler
import albumentations
#import numpy as np
import cv2
#import torch

def compute_optical_flow_batch(images):
    """
    images: numpy array of shape (n, 2, h, w, c)
    returns: numpy array of shape (n, 2, h, w)
    """
    n, _, h, w, c = images.shape
    flows = []

    for i in range(n):
        # 获取当前样本的前后帧
        frame1 = images[i, 0]  # (h, w, c)
        frame2 = images[i, 1]  # (h, w, c)

        # 转灰度
        prev_gray = cv2.cvtColor(frame1.astype(np.uint8), cv2.COLOR_RGB2GRAY)
        next_gray = cv2.cvtColor(frame2.astype(np.uint8), cv2.COLOR_RGB2GRAY)

        # 计算光流 (Farneback)
        flow = cv2.calcOpticalFlowFarneback(
            prev=prev_gray,
            next=next_gray,
            flow=None,
            pyr_scale=0.5,
            levels=3,
            winsize=15,
            iterations=3,
            poly_n=5,
            poly_sigma=1.2,
            flags=0
        )  # 返回 (h, w, 2)

        # 转置为 (2, h, w)
        flow = np.transpose(flow, (2, 0, 1))
        flows.append(flow)

    # 合并为 (n, 2, h, w)
    flows = np.stack(flows, axis=0)
    return flows



def changedim(x):
    assert x.ndim == 5 and x.shape[1:] == (2, 32, 32, 3), "Input shape mismatch"
    x =  np.transpose(x,(0,2,3,4,1))
    merged = np.concatenate(np.split(x, 2, axis=-1), axis=2)
    data = np.transpose(merged.squeeze(-1), (0, 3, 1, 2))  # (n, 3, 32, 64)

    return data


class SetData():
    def __init__(self, object_array, root, img_size, seed, noise, noise_num, obj, bg, md):
        self.train_data, self.train_label, self.valid_data, self.valid_label = self.import_dataset(
            object_array, root, img_size, seed, noise, noise_num, obj, bg, md)

    def import_dataset(self, object_array, root, img_size, seed, noise, noise_num, obj, bg, md):

        train_data = []
        train_label = []
        test_data = []
        test_label = []

        train_i = 0
        test_i = 0

        if noise == True:
            root = root + "/" + noise_num

        for load_object in object_array:
            x = np.load(
                'B:/dataset/color_motion_uint8/' + str(obj) + '/' + str(bg) + '/image/' + str(load_object) + '.npy'
                        )
            t = np.load(
                'B:/dataset/color_motion_uint8/' + str(obj) + '/' + str(bg) + '/label/' + str(load_object) + '.npy'
                        )


            perm = np.random.RandomState(seed=seed).permutation(len(x))
            x = x[perm]
            # x = x.transpose(0, 1, 4, 2, 3)
            if str(md) != "HMBD":
                if str(md) == "4LCNN":
                    x = compute_optical_flow_batch(x)
                    # t = np.argmax(t, axis = 1)
                # x = changedim(x)
                else:
                    x = x.transpose(0, 1, 4, 2, 3)
            t = t[perm]
            print(x.shape)
            #t = t[0:10000]


            # Training Test 比率
#             train_data[train_i:train_i+ 7500] = x[:7500] * 1
#             train_label[train_i:train_i+7500] = t[:7500] * 1
#             train_i += 7500

#             test_data[test_i:test_i+2500] = x[7500:10000] * 1
#             test_label[test_i:test_i+2500] = t[7500:10000] * 1
#             test_i += 2500
            train_data[train_i:train_i+ 2500] = x[:2500] * 1
            train_label[train_i:train_i+2500] = t[:2500] * 1
            train_i += 2500

            test_data[test_i:test_i+1500] = x[1500:4000] * 1
            test_label[test_i:test_i+1500] = t[1500:4000] * 1
            test_i += 1500

            #print("import " +str(load_object) + "pixel dataset" + "rate" + train_i + ":" + test_i )

        train_data = np.array(train_data)
       # train_data = padding4EfN(train_data)################使用EFN时
        train_label = np.array(train_label)
        # train_label = np.argmax(train_label, axis=1)

        test_data = np.array(test_data)
       # test_data = padding4EfN(test_data)################使用EFN时
        test_label = np.array(test_label)
        
        # test_label = np.argmax(test_label, axis=1)

        perm_train = np.random.RandomState(seed=seed).permutation(len(train_data))
        train_data = train_data[perm_train][:7500]

        train_label = train_label[perm_train][:7500]
        train_label = np.argmax(train_label, axis =1)#4ResNet
        perm_test = np.random.RandomState(seed=seed).permutation(len(test_data))
        test_data = test_data[perm_test][:2500]
        test_label = test_label[perm_test][:2500]
        print(test_label.shape)
        test_label = np.argmax(test_label, axis =1)#4ResNet

        return train_data, train_label, test_data, test_label

    def set_train_data_Loader(self, batch_size):
        train_dataset = MotionDetectionDataset(
            data=self.train_data, label=self.train_label)

        train_loader = DataLoader(
            train_dataset,
            batch_size=batch_size,
            shuffle=True,
            pin_memory=True,
            num_workers=0,
        )

        return train_loader

    def set_valid_data_Loader(self, batch_size):
        valid_dataset = MotionDetectionDataset(
            data=self.valid_data, label=self.valid_label)

        valid_loader = DataLoader(
            valid_dataset,
            batch_size=batch_size,
            shuffle=False,
            pin_memory=True,
            num_workers=0,
        )

        return valid_loader


class MotionDetectionDataset(torch.utils.data.Dataset):
    def __init__(self, data, label):
        self.data = torch.from_numpy(data)
        self.data_num = len(data)
        self.label = label

    def __len__(self):
        return self.data_num

    def __getitem__(self, idx):
        out_data = self.data[idx].to(torch.float32)
        out_label = self.label[idx]

        # channelを増やす
        # return out_data[np.newaxis, :, :], out_label
        return out_data, out_label #EfN用
