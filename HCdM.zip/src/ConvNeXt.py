import torch
import torchvision
import torch.nn as nn
import torch.nn.functional as F
import timm

class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=1):
        super(ConvBlock, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding)
        self.bn = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=False)  # 禁用inplace操作

    def forward(self, x):
        out = self.conv(x)
        out = self.bn(out)
        out = self.relu(out)
        return out

class ConvNeXtBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1):
        super(ConvNeXtBlock, self).__init__()
        self.conv1x1_1 = ConvBlock(in_channels, out_channels // 2, kernel_size=1, stride=stride, padding=0)
        self.conv3x3 = ConvBlock(out_channels // 2, out_channels // 2, kernel_size=3, stride=1, padding=1)
        self.conv1x1_2 = ConvBlock(out_channels // 2, out_channels, kernel_size=1, stride=1, padding=0)
        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels)
            )

    def forward(self, x):
        out = self.conv1x1_1(x)
        out = self.conv3x3(out)
        out = self.conv1x1_2(out)
        out += self.shortcut(x)
        out = F.relu(out, inplace=False)  # 禁用inplace操作
        return out

class ConvNeXt(nn.Module):
    def __init__(self, num_classes=4):
        super(ConvNeXt, self).__init__()
        self.conv1 = ConvBlock(3, 64, kernel_size=7, stride=2, padding=3)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.conv2 = self._make_layer(64, 128, 3, stride=2)
        self.conv3 = self._make_layer(128, 256, 4, stride=2)
        self.conv4 = self._make_layer(256, 512, 6, stride=2)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512, num_classes)

    def _make_layer(self, in_channels, out_channels, num_blocks, stride):
        layers = []
        layers.append(ConvNeXtBlock(in_channels, out_channels, stride))
        for _ in range(1, num_blocks):
            layers.append(ConvNeXtBlock(out_channels, out_channels))
        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.conv1(x)
        x = self.maxpool(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x





class ConvNeXtForClassification(nn.Module):
    def __init__(self, num_classes=8):
        super(ConvNeXtForClassification, self).__init__()
        # 使用timm库加载预训练的ConvNeXt模型
        self.model = timm.create_model('convnext_base', pretrained=True)
        # 获取模型的最后一层输入特征数
        num_features = self.model.head.fc.in_features
        # 替换最后的分类器为适应四分类问题
        self.model.head.fc = nn.Linear(num_features, num_classes)

    def forward(self, x):
        return self.model(x)



class ConvNeXtLee(nn.Module):
    def __init__(self, device, num_classes, pretrained):
        super().__init__()
        self.device = device
        self.num_classes = num_classes

        if pretrained:
            self.front_component = torchvision.models.convnext_base(weights = torchvision.models.ConvNeXt_Base_Weights.DEFAULT)
        else:
            self.front_component = torchvision.models.convnext_base(weights=None)

        self.output_layer = nn.Linear(1000, num_classes)
        self.model = nn.Sequential(self.front_component, self.output_layer)

    def forward(self, x):
        return self.model(x)




class Block(nn.Module):
    def __init__(self, dim, drop_path=0., layer_scale_init_value=1e-6):
        super().__init__()
        self.dwconv = nn.Conv2d(dim, dim, kernel_size=7, padding=3, groups=dim)  # depthwise conv
        self.norm = nn.LayerNorm(dim, eps=1e-6)
        self.pwconv1 = nn.Linear(dim, 4 * dim)  # pointwise/1x1 convs, implemented with linear layers
        self.act = nn.GELU()
        self.pwconv2 = nn.Linear(4 * dim, dim)
        self.gamma = nn.Parameter(layer_scale_init_value * torch.ones((dim,)), requires_grad=True) if layer_scale_init_value > 0 else None
        self.drop_path = nn.Identity() if drop_path == 0. else DropPath(drop_path)

    def forward(self, x):
        input = x
        x = self.dwconv(x)
        x = x.permute(0, 2, 3, 1)  # NCHW to NHWC
        x = self.norm(x)
        x = self.pwconv1(x)
        x = self.act(x)
        x = self.pwconv2(x)
        if self.gamma is not None:
            x = self.gamma * x
        x = x.permute(0, 3, 1, 2)  # NHWC to NCHW

        x = input + self.drop_path(x)
        return x

class ConvNeXtQ(nn.Module):
    def __init__(self, depths, dims, num_classes=8):
        super().__init__()
        self.downsample_layers = nn.ModuleList()  # stem and 3 intermediate downsampling conv layers
        stem = nn.Sequential(
            nn.Conv2d(3, dims[0], kernel_size=2, stride=2),#yixiugai
            LayerNorm(dims[0], eps=1e-6, data_format="channels_first")
        )
        self.downsample_layers.append(stem)
        for i in range(3):
            downsample_layer = nn.Sequential(
                LayerNorm(dims[i], eps=1e-6, data_format="channels_first"),
                nn.Conv2d(dims[i], dims[i+1], kernel_size=2, stride=2),
            )
            self.downsample_layers.append(downsample_layer)

        self.stages = nn.ModuleList()  # 4 feature resolution stages, each consisting of multiple residual blocks
        dp_rates = [x.item() for x in torch.linspace(0, 0.1, sum(depths))]  # stochastic depth decay rule
        cur = 0
        for i in range(4):
            stage = nn.Sequential(
                *[Block(dim=dims[i], drop_path=dp_rates[cur + j]) for j in range(depths[i])]
            )
            self.stages.append(stage)
            cur += depths[i]

        self.norm = nn.LayerNorm(dims[-1], eps=1e-6)  # final norm layer
        self.head = nn.Linear(dims[-1], num_classes)

    def forward(self, x):
        for downsample_layer, stage in zip(self.downsample_layers, self.stages):
            x = downsample_layer(x)
            x = stage(x)
        x = self.norm(x.mean([-2, -1]))  # global average pooling, (N, C, H, W) -> (N, C)
        x = self.head(x)
        return x

class LayerNorm(nn.Module):
    def __init__(self, normalized_shape, eps=1e-6, data_format="channels_last"):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps
        self.data_format = data_format
        if self.data_format not in ["channels_last", "channels_first"]:
            raise ValueError(f"not supported data format: {self.data_format}")

    def forward(self, x):
        if self.data_format == "channels_last":
            return nn.functional.layer_norm(x, x.shape[-1:], self.weight, self.bias, self.eps)
        elif self.data_format == "channels_first":
            u = x.mean(1, keepdim=True)
            s = (x - u).pow(2).mean(1, keepdim=True)
            x = (x - u) / torch.sqrt(s + self.eps)
            return self.weight[:, None, None] * x + self.bias[:, None, None]

class DropPath(nn.Module):
    def __init__(self, drop_prob=None):
        super(DropPath, self).__init__()
        self.drop_prob = drop_prob

    def forward(self, x):
        return self.drop_path(x)

    def drop_path(self, x):
        if self.drop_prob == 0. or not self.training:
            return x
        keep_prob = 1 - self.drop_prob
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)
        random_tensor = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
        random_tensor.floor_()
        output = x.div(keep_prob) * random_tensor
        return output

def convnext_tiny(num_classes=8):
    depths = [3, 3, 9, 3]
    dims = [96, 192, 384, 768]
    return ConvNeXtQ(depths, dims, num_classes)


