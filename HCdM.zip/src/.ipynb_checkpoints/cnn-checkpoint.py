from multiprocessing import pool
from numpy import dtype
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from net import FrontConv
from efficientnet_pytorch import EfficientNet

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class FourLayerCNN(nn.Module):
    def __init__(
        self,
        input_dim=((1, 32, 32)),
        output_dim=((900, 9)),
        filter_size=3,
        pad=1
    ):
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.filter_size = filter_size
        self.pad = pad
        image_w = input_dim[0]
        self.activate = nn.ReLU()
        self.stride = 1

        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=pad)
        self.maxpool1 = nn.MaxPool2d(kernel_size=2)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=pad)
        self.maxpool2 = nn.MaxPool2d(kernel_size=2)
        self.conv3 = nn.Conv2d(16, 32, kernel_size=3, padding=pad)
        self.maxpool3 = nn.MaxPool2d(kernel_size=2)
        self.fc1 = nn.Linear(4*4*32, 4)
        self.softmax = nn.Softmax(dim=0)

    def forward(self, x):
        x = self.conv1(x)
        x = self.activate(x)
        x = self.maxpool1(x)
        x = self.conv2(x)
        x = self.activate(x)
        x = self.maxpool2(x)
        x = self.conv3(x)
        x = self.activate(x)
        x = self.maxpool3(x)
        x = x.view(x.shape[0], -1)
        x = self.fc1(x)

        return x


class OneChCNN(nn.Module):
    def __init__(
        self,
        input_dim=((1, 32, 32)),
        output_dim=((900, 9)),
        filter_size=3,
        pad=0
    ):
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.filter_size = filter_size
        self.pad = pad
        image_w = input_dim[0]

        self.stride = 1

        self.frontConv = FrontConv()
        self.activate = nn.Sigmoid()
        self.softmax = nn.Softmax(dim=0)

        self.W = nn.Parameter(torch.Tensor(0.01 * np.random.randn(900, 4)))
        self.q = nn.Parameter(torch.Tensor(np.zeros((4))))

    def forward(self, x):
        # im2col
        x = self.frontConv(x)
        x = x.to(device)
        x = torch.matmul(x, self.W)
        x = torch.sum(self.activate(x + self.q), dim=1)
        return x

class EfficientNetB0(nn.Module):
    def __init__(self, num_classes):
        super(EfficientNetB0, self).__init__()
        self.model = EfficientNet.from_pretrained('efficientnet-b0')
        self.model._fc = nn.Linear(self.model._fc.in_features, num_classes)  # 更改输出类别数量

    def forward(self, x):
        x = self.model(x)
        return x
# class TwoChCNN(nn.Module):
#     def __init__(
#         self,
#         input_dim=((2, 32, 32)),
#         output_dim=((900, 9)),
#         filter_size=3,
#         pad=0
#     ):
#         super().__init__()
#         self.input_dim = input_dim
#         self.output_dim = output_dim
#         self.filter_size = filter_size
#         self.pad = pad
#         image_w = input_dim[2]
#         self.activate = nn.Sigmoid()
#         self.stride = 1
#
#         self.conv1 = nn.Conv2d(2, 8, kernel_size=3, padding=pad)
#         self.flatten = nn.Flatten(2, -1)
#
#     def forward(self, x):
#         # im2col
#         x = self.conv1(x)
#         x = self.activate(x)
#         x = x.view(x.shape[0], x.shape[1], -1)
#         x = torch.sum(x, dim=2)
#         return x
#
#
# class OneChFCCNN(nn.Module):
#     def __init__(
#         self,
#         input_dim=((2, 32, 32)),
#         output_dim=((900, 9)),
#         filter_size=3,
#         pad=0
#     ):
#         super().__init__()
#         self.input_dim = input_dim
#         self.output_dim = output_dim
#         self.filter_size = filter_size
#         self.pad = pad
#         image_w = input_dim[2]
#
#         self.stride = 1
#
#         self.frontConv = FrontConv()
#         self.activate = nn.Sigmoid()
#         self.fc1 = nn.Linear((image_w-2)*(image_w-2)*8, 8)
#         self.softmax = nn.Softmax(dim=0)
#
#         self.W = nn.Parameter(torch.Tensor(0.01 * np.random.randn(9, 8)))
#         self.q = nn.Parameter(torch.Tensor(np.zeros((8))))
#
#     def forward(self, x):
#         # im2col
#         x = self.frontConv(x)
#         x = torch.matmul(x, self.W)
#         x = self.activate(x + self.q)
#         x = x.view(x.shape[0], -1)
#         x = self.fc1(x)
#
#         return x
#
#
# class TwoChFCCNN(nn.Module):
#     def __init__(
#         self,
#         input_dim=((2, 32, 32)),
#         output_dim=((900, 9)),
#         filter_size=3,
#         pad=0
#     ):
#         super().__init__()
#         self.input_dim = input_dim
#         self.output_dim = output_dim
#         self.filter_size = filter_size
#         self.pad = pad
#         image_w = input_dim[2]
#         self.activate = nn.Sigmoid()
#         self.stride = 1
#
#         self.conv1 = nn.Conv2d(2, 8, kernel_size=3, padding=pad)
#         self.fc1 = nn.Linear((image_w-2)*(image_w-2)*8, 8)
#         self.flatten = nn.Flatten(2, -1)
#         self.softmax = nn.Softmax(dim=0)
#
#     def forward(self, x):
#         # im2col
#         x = self.conv1(x)
#         x = self.activate(x)
#         x = x.view(x.shape[0], -1)
#         x = self.fc1(x)
#         return x
